% EMB System by Robots5 LLC (USA)
% Inverted Pendulum with LQR MATLAB Script. Use with the appropriate SIMULINK File

%% GENERAL PARAMETERS

clear all; clc;

T = 0.001; % sampling time (change to fit your experiment)

S = inf;   % simulation duration time (change to fit your experiment)

r = 0.01; % pinion gear radius [m]

Kt = 0.0273; % torque constant for the EMB-AM4 actuator [Nm/A]

% Kt = 0.028; % torque constant for the EMB-AM2 actuator [Nm/A]

motor_eff = 1.0; % system efficiency (change to match your plant)

Kt = Kt*motor_eff; % including efficiency, actual Kt used in Simulink


%% Plant Parameters

M = 1.330;      % cart mass [kg]
m = 0.072;      % pendulum mass [kg]
l = 0.136;      % length to mass [m]
g = 9.81;       % gravity [m/s^2]
b = 0.5;        % cart damping [N*s/m], (change to match your plant)
c = 0.001;      % pendulum damping [N*m*s/rad], (change to match your plant)

%% State-space matrices

% States: cart position, cart velocity, pend angle, pend angular velocity

I = m*l^2; 

%I=0; % assume I to be massless rod with a point mass m at distance l

A = [ 0, 1.0, 0, 0;
      0, -(I + m*l^2)*b/(I*(M + m) + M*m*l^2), (m^2*g*l^2)/(I*(M + m) + M*m*l^2), -(m*l*c)/(I*(M + m) + M*m*l^2);
      0, 0, 0, 1.0;
      0, -(m*l*b)/(I*(M + m) + M*m*l^2), m*g*l*(M + m)/(I*(M + m) + M*m*l^2), -(M + m)*c/(I*(M + m) + M*m*l^2) ];

B = [ 0;
      (I + m*l^2)/(I*(M + m) + M*m*l^2);
      0;
      m*l/(I*(M + m) + M*m*l^2) ];

C = eye(4); % full-state measurement

D = zeros(4,1);

sys = ss(A,B,C,D);

disp('A ='); disp(A);
disp('B ='); disp(B);
disp('C ='); disp(C);
disp('D ='); disp(D);

pzmap(sys); grid on;

disp('Eigenvalues of A:');
disp(eig(A));


%% LQR controller

%Q = diag([3000, 10, 1000, 3]);  % weight states, tune

R = 0.1;                         % weight input, tune

Q = diag([1000, 10, 500, 5]);    % weight states, tune


% physics-based tuning process:

x_max = 0.035;
xdot_max = 1.0;
theta_max = 8*pi/180;
thetadot_max = 2.0;
u_max = 10;

Q = diag([
    1/x_max^2,
    1/xdot_max^2,
    1/theta_max^2,
    1/thetadot_max^2
]);

R = 1/u_max^2;

K = lqr(A,B,Q,R);

disp('LQR Gain K:');
disp(K);

Acl = A - B*K;
sys_cl = ss(Acl,B,C,D);

sys_c = ss(A,B,eye(4),0);
sys_d = c2d(sys_c, T);

Ad = sys_d.A;
Bd = sys_d.B;
Kd = dlqr(Ad, Bd, Q, R);

disp('Discrete LQR Gain Kd:');
disp(Kd);


%% Filter to get Velocity (optional if used with derivative for velocities)

filter_vel_c = tf([1 0], [0.05 1]); 
filter_vel_d = c2d(filter_vel_c, T, 'tustin');

[num_filter_vel_d, den_filter_vel_d] = tfdata(filter_vel_d, 'v');


%% Observer design

% Measured outputs
C_meas = [1 0 0 0;
          0 0 1 0];

% Discrete system
sys_d = c2d(ss(A,B,C,D), T);
Ad = sys_d.A;
Bd = sys_d.B;

% LQR
Kd = dlqr(Ad, Bd, Q, R);

% Closed-loop poles (discrete)
cl_poles_d = eig(Ad - Bd*Kd);

% Observer poles (faster but reasonable)
observer_speed_factor = 8;

p_obs_d = cl_poles_d .^ observer_speed_factor;

% Observer gain
Ld = place(Ad', C_meas', p_obs_d)';

% ---- Observer system matrices ----

A_obs_d = Ad - Ld*C_meas;
B_obs_d = [Bd, Ld];     % inputs: u and y
C_obs_d = eye(4);
D_obs_d = zeros(4, 1 + size(C_meas,1));

%%