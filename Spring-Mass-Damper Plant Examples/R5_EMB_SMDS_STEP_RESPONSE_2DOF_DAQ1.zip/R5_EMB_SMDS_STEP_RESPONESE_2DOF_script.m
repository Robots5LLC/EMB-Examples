% EMB System by Robots5 LLC (USA)
% Spring-Mass-Damper Kit 2DOF - System Response - MATLAB Script. Use with the appropriate SIMULINK File

%% GENERAL PARAMETERS

T = 0.002; % sampling time (change to fit your experiment)

S = 4;   % simulation duration time (change to fit your experiment)

r = 0.01; % pinion gear radius [m]

Kt = 0.0273; % torque constant for the EMB-AM4 actuator [Nm/A]

%Kt = 0.028; % torque constant for the EMB-AM2 actuator [Nm/A]

motor_eff = 1.0; % system efficiency (change to match your plant)

Kt = Kt*motor_eff; % including efficiency, actual Kt used in Simulink

%% PLOTTING - Step System Response - Position

plot(rt_time,cart1_position, rt_time, cart2_position, 'LineWidth',2)
title('Position vs. Time')
xlabel('Time [s]')
ylabel('Position [m]')
grid on

%% PLOTTING - Step System Response - Velocity

plot(rt_time,cart1_velocity, rt_time, cart2_velocity, 'LineWidth',2)
title('Velocity vs. Time')
xlabel('Time [s]')
ylabel('Velocity [m/s]')
grid on

%%
