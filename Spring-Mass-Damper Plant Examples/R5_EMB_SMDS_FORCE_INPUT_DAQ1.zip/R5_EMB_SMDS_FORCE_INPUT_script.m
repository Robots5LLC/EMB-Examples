% EMB System by Robots5 LLC (USA)
% Spring-Mass-Damper Kit - System Response - MATLAB Script. Use with the appropriate SIMULINK File

%% GENERAL PARAMETERS

T = 0.002; % sampling time (change to fit your experiment)
S = 10;   % simulation duration time (change to fit your experiment)

r = 0.01; % pinion gear radius [m]

Kt = 0.0273; % torque constant for the EMB-AM4 actuator [Nm/A]

%Kt = 0.028; % torque constant for the EMB-AM2 actuator [Nm/A]

motor_eff = 1.0; % system efficiency (change to match your plant)

Kt = Kt*motor_eff; % including efficiency, actual Kt used in Simulink


%% PLOTTING - CURRENT

plot(rt_time, i_input, rt_time, i_measure, 'LineWidth',2)
title('Current vs. Time')
xlabel('Time [s]')
ylabel('Current [A]')
legend('Input Current','Measured Current')
grid on

%%